#include "utils.h"
#define NUMBER_OF_FILES 10
int shellSort(int *arr, int n, char *ofile) 
{   
    struct timeval tv1, tv2;
    gettimeofday(&tv1, NULL);
    FILE *out = fopen(ofile, "w");
    for (int gap = n/2; gap > 0; gap /= 2) 
    { 
        for (int i = gap; i < n; i += 1) 
        { 
            int temp = arr[i]; 
            int j;             
            for (j = i; j >= gap && arr[j - gap] > temp; j -= gap) 
                arr[j] = arr[j - gap]; 
              
            arr[j] = temp; 
        } 
    } 
    fprintf(out,"Sorted array : ");
    for(int i = 0; i < n ;i++){
        fprintf(out, "%d ", arr[i]);
    }
    fprintf(out,"\n");
    gettimeofday(&tv2, NULL);
    fprintf(out, "Time in miliseconds : %ld\n\n", execTime(tv1, tv2));
    fclose(out);
    return 0; 
} 
  

  
int main()
{
	int n, i;
	FILE *in;
	FILE *out;
	char ifile[20], ofile[20];
	int max;
    int *a;
	for (i = 1; i <= NUMBER_OF_FILES; i++)
	{
		sprintf(ifile, "test%d.in", i);
		sprintf(ofile, "test%d.out", i);
		in = fopen(ifile, "r");
		out = fopen(ofile, "w");
		if (in == NULL)
		{
			printf("ERROR\n");
			return 0;
		}
		else
		{
			printf("Preaparing file :%d\n", i);
			sleep(1);
		}
		char *line = NULL;
		size_t len = 0;
		ssize_t read;
		int first = 1;
		
		int counter = 0;
		int numberOfelem;
		int howM = 0;
		while ((read = getline(&line, &len, in)) != -1)
		{
			if(first == 1){
				numberOfelem = atoi(line);
				a = (int *)malloc(sizeof(int )*atoi(line));
				first = 0;
				goto NEXT;
			}
			char *token = NULL;
			token = strtok(line," ");
			while (token != NULL)
			{
				a[counter] = atoi(token);
				token = strtok(NULL, " ");
				counter++;
			}
			NEXT:
			howM++;
		}
        
		shellSort(a,numberOfelem,ofile);
        free(a);
		first = 1;
		counter = 0;
		
        //int numberOflines = sizeOfFile(ifile);
		//
		//
		
		//NEXT:
		fclose(in);
		fclose(out);
	
	}

	printf("Successfully Builded :)\n");
	return 0;
}