//#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
long execTime(struct timeval tv1, struct timeval tv2)
{
    long timeStamp = tv2.tv_usec - tv1.tv_usec;
    return timeStamp;
}
int *elemFromFile(char *ifile, int numberOflines)
{
    FILE *in = fopen(ifile, "r");
    int *a = (int *)malloc(sizeof(int) * numberOflines);
    int numberFromFile;
    int contor = 0;
    fscanf(in, "%d", &numberFromFile);
    while (!feof(in))
    {
        a[contor] = numberFromFile;
        fscanf(in, "%d", &numberFromFile);
        contor++;
    }
    fclose(in);
    return a;
}
int sizeOfFile(char *ifile)
{
    FILE *fp = fopen(ifile, "r");
    int lines = 0;
    char ch;
    while (!feof(fp))
    {
        ch = fgetc(fp);
        if (ch == '\n')
        {
            lines++;
        }
    }
    fclose(fp);
    return lines;
}
int maxArray(int *a, int n)
{
    int i;
    int max = a[0];

    for (i = 1; i < n; ++i)
    {
        if (a[i] > max)
            max = a[i];
    }
    return max;
}
void printArray(int arr[], int n) 
{ 
    for (int i=0; i<n; i++) 
        printf("%d ", arr[i]);
}
