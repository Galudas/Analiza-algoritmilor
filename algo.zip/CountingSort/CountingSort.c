/*Counting sort !!! 
  Fiecare fisier de input au cate un fisier de output 
*/
#include "utils.h"
#define NUMBER_OF_FILES 10

void counting_sort(char *ofile, int *a, int n, int max)
{   
    FILE *out = fopen(ofile, "w");
    struct timeval tv1, tv2;
    gettimeofday(&tv1, NULL);
    int i, j;
    if(n == 0){
        printf("Empty\n");
        return;
    }
    int *count = (int *)calloc(max + 1, sizeof(int));
    for (i = 0; i < n; ++i)
        count[a[i]] = count[a[i]] + 1;

    fprintf(out, "\nSorted elements are: ");
    for (i = 0; i <= max; ++i)
        for (j = 1; j <= count[i]; ++j)
        {
            fprintf(out, "%d ", i);
        }
    fprintf(out, "\n");
    free(count);
    gettimeofday(&tv2, NULL);
    fprintf(out, "Time in miliseconds : %ld\n\n", execTime(tv1, tv2));
    fclose(out);
}


int main()
{
	int n, i;
	FILE *in;
	FILE *out;
	char ifile[20], ofile[20];
	int max;
    int *a;
	for (i = 1; i <= NUMBER_OF_FILES; i++)
	{
		sprintf(ifile, "test%d.in", i);
		sprintf(ofile, "test%d.out", i);
		in = fopen(ifile, "r");
		out = fopen(ofile, "w");
		if (in == NULL)
		{
			printf("ERROR\n");
			return 0;
		}
		else
		{
			printf("Preaparing file :%d\n", i);
			sleep(1);
		}
		char *line = NULL;
		size_t len = 0;
		ssize_t read;
		int first = 1;
		
		int counter = 0;
		int numberOfelem;
		int howM = 0;
		while ((read = getline(&line, &len, in)) != -1)
		{
			if(first == 1){
				numberOfelem = atoi(line);
				a = (int *)malloc(sizeof(int )*atoi(line));
				first = 0;
				goto NEXT;
			}
			char *token = NULL;
			token = strtok(line," ");
			while (token != NULL)
			{
				a[counter] = atoi(token);
				token = strtok(NULL, " ");
				counter++;
			}
			NEXT:
			howM++;
		}
        
		//printArray(a,numberOfelem);
        max = maxArray(a,numberOfelem);
        counting_sort(ofile, a, numberOfelem,max);
        free(a);
		first = 1;
		counter = 0;
		//int numberOflines = sizeOfFile(ifile);
		//
		//
		
		//NEXT:
		fclose(in);
		//fclose(out);
	
	}

	printf("Successfully Builded :)\n");
	return 0;
}