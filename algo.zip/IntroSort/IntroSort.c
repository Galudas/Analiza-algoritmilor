#include <stdio.h>
#include "utils.h"
#define NUMBER_OF_FILES 10
int Log2n(unsigned int n)
{
	return (n > 1) ? 1 + Log2n(n / 2) : 0;
}
void InsertionSort(int *data, int count)
{
	for (int i = 1; i < count; ++i)
	{
		int j = i;

		while (j > 0)
		{
			if (data[j - 1] > data[j])
			{
				data[j - 1] ^= data[j];
				data[j] ^= data[j - 1];
				data[j - 1] ^= data[j];

				--j;
			}
			else
			{
				break;
			}
		}
	}
}

void MaxHeapify(int *data, int heapSize, int index)
{
	int left = (index + 1) * 2 - 1;
	int right = (index + 1) * 2;
	int largest = 0;

	if (left < heapSize && data[left] > data[index])
		largest = left;
	else
		largest = index;

	if (right < heapSize && data[right] > data[largest])
		largest = right;

	if (largest != index)
	{
		int temp = data[index];
		data[index] = data[largest];
		data[largest] = temp;

		MaxHeapify(data, heapSize, largest);
	}
}

void HeapSort(int *data, int count)
{
	int heapSize = count;

	for (int p = (heapSize - 1) / 2; p >= 0; --p)
		MaxHeapify(data, heapSize, p);

	for (int i = count - 1; i > 0; --i)
	{
		int temp = data[i];
		data[i] = data[0];
		data[0] = temp;

		--heapSize;
		MaxHeapify(data, heapSize, 0);
	}
}

int Partition(int *data, int left, int right)
{
	int pivot = data[right];
	int temp;
	int i = left;

	for (int j = left; j < right; ++j)
	{
		if (data[j] <= pivot)
		{
			temp = data[j];
			data[j] = data[i];
			data[i] = temp;
			i++;
		}
	}

	data[right] = data[i];
	data[i] = pivot;

	return i;
}

void QuickSortRecursive(int *data, int left, int right)
{
	if (left < right)
	{
		int q = Partition(data, left, right);
		QuickSortRecursive(data, left, q - 1);
		QuickSortRecursive(data, q + 1, right);
	}
}

int IntroSort(int *data, int numberOflines, char *ofile)
{
	struct timeval tv1, tv2;
	gettimeofday(&tv1, NULL);
	FILE *out = fopen(ofile, "w");
	if(numberOflines == 0){
		printf("Skip File\n");
		fclose(out);
		return -1;
	}
	
	int partitionSize = Partition(data, 0, numberOflines - 1);

	if (partitionSize < 16)
	{
		InsertionSort(data, numberOflines);
	}
	else if (partitionSize > (2 * Log2n(numberOflines)))
	{
		HeapSort(data, numberOflines);
	}
	else
	{
		QuickSortRecursive(data, 0, numberOflines - 1);
	}
	fprintf(out, "Sorted Array : ");
	for (int i = 0; i < numberOflines; i++)
	{
		fprintf(out, "%d ", data[i]);
	}
	fprintf(out, "\n");
	gettimeofday(&tv2, NULL);
	fprintf(out, "Time in miliseconds : %ld\n\n", execTime(tv1, tv2));
	return 0;
}
int main()
{
	int n, i;
	FILE *in;
	FILE *out;
	char ifile[20], ofile[20];
	int max;
	for (i = 1; i <= NUMBER_OF_FILES; i++)
	{
		sprintf(ifile, "test%d.in", i);
		sprintf(ofile, "test%d.out", i);
		in = fopen(ifile, "r");
		out = fopen(ofile, "w");
		if (in == NULL)
		{
			printf("ERROR\n");
			return 0;
		}
		else
		{
			printf("Preaparing file :%d\n", i);
			sleep(1);
		}
		char *line = NULL;
		size_t len = 0;
		ssize_t read;
		int first = 1;
		int *a;
		int counter = 0;
		int numberOfelem;
		int howM = 0;
		while ((read = getline(&line, &len, in)) != -1)
		{
			if(first == 1){
				numberOfelem = atoi(line);
				a = (int *)malloc(sizeof(int)*atoi(line));
				first = 0;
				goto NEXT;
			}
			char *token = NULL;
			token = strtok(line," ");
			while (token != NULL)
			{
				a[counter] = atoi(token);
				token = strtok(NULL, " ");
				counter++;
			}
			NEXT:
			howM++;
		}
		//printArray(a,numberOfelem);
		int freeOrNot = IntroSort(a, numberOfelem,ofile);
		if(freeOrNot == 0){
			free(a);
		}
		first = 1;
		counter = 0;
		//int numberOflines = sizeOfFile(ifile);
		//
		//
		//free(a);
		//NEXT:
		fclose(in);
		fclose(out);
	
	}

	printf("Successfully Builded :)\n");
	return 0;
}