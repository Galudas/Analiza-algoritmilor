#include <stdio.h>
#include <math.h>
unsigned int Log2n(unsigned int n){
    return (n > 1) ? 1 + Log2n(n/2) : 0;
}
int main () {
   unsigned int x = ;
   /* finding log(2.7) */
   printf("log(%d) = %d", x, Log2n(x));
   
   return(0);
}