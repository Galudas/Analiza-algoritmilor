/*Counting sort !!! 
  Fiecare fisier de input are are cate un fisier de output 
*/
#include "utils.h"
#define NUMBER_OF_FILES 10

void counting_sort(char *ofile, int a[], int n, int max)
{
    FILE *out = fopen(ofile, "w");
    struct timeval tv1, tv2;
    gettimeofday(&tv1, NULL);
    int i, j;
    int *count = (int *)calloc(max, sizeof(int));
    for (i = 0; i < n; ++i)
        count[a[i]] = count[a[i]] + 1;

    fprintf(out, "\nSorted elements are: ");
    for (i = 0; i <= max; ++i)
        for (j = 1; j <= count[i]; ++j)
        {
            fprintf(out, "%d ", i);
        }
    fprintf(out, "\n");
    free(count);
    gettimeofday(&tv2, NULL);
    fprintf(out, "Time in miliseconds : %ld\n\n", execTime(tv1, tv2));
    fclose(out);
}
void sort()
{

    int *a, n, i;
    FILE *in;
    FILE *out;
    char ifile[20], ofile[20];
    int max;
    for (i = 1; i <= NUMBER_OF_FILES; i++)
    {
        sprintf(ifile, "input%d.txt", i);
        sprintf(ofile, "output%d.txt", i);
        in = fopen(ifile, "r");
        out = fopen(ofile, "w");
        if (in == NULL)
        {
            printf("ERROR\n");
            return;
        }
        else
        {
            printf("Preaparing file :%d\n", i);
            sleep(1);
        }

        int numberOflines = sizeOfFile(ifile);
        a = elemFromFile(ifile, numberOflines);
        max = maxArray(a, numberOflines);
        counting_sort(ofile, a, numberOflines, max);
        free(a);
    }
}
int main()
{
    sort();
    printf("Successfully Builded :)\n");
    return 0;
}
